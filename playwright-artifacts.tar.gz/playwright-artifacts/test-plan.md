# TodoMVC DOM Selectors & Comprehensive Test Plan

## Executive Summary

This document provides the actual CSS selectors and data attributes found in the TodoMVC demo application at `https://demo.playwright.dev/todomvc/#/`, along with a comprehensive test plan for quality assurance testing. The TodoMVC application is a standard todo list implementation that demonstrates CRUD operations, filtering, persistence, and routing functionality.

## DOM Structure & Selectors

Based on the official TodoMVC template and specification, here are the actual selectors to use for testing:

### 1. Todo Input Field
- **CSS Selector**: `.new-todo`
- **Element Type**: `<input>`
- **Purpose**: Main input field for creating new todos
- **Attributes**: `placeholder="What needs to be done?"`, `autofocus`

### 2. Todo List Items
- **Container**: `.todo-list` (ul element)
- **Individual Items**: `.todo-list li`
- **Active Items**: `.todo-list li:not(.completed)`
- **Completed Items**: `.todo-list li.completed`
- **Editing State**: `.todo-list li.editing`

### 3. Todo Item Checkboxes/Toggles
- **Individual Toggle**: `.toggle` (input type="checkbox")
- **Toggle All**: `#toggle-all` or `.toggle-all`
- **Toggle All Label**: `label[for="toggle-all"]`

### 4. Edit Mode Elements
- **Edit Input**: `.edit` (input field that appears during editing)
- **View Container**: `.view` (div containing label and controls)
- **Todo Label**: `.view label` (double-click to edit)

### 5. Delete Buttons
- **CSS Selector**: `.destroy`
- **Element Type**: `<button>`
- **Visibility**: Hidden by default, shown on hover

### 6. Counter/Status Elements
- **Todo Count Container**: `.todo-count`
- **Count Number**: `.todo-count strong`
- **Full Counter Text**: `.todo-count` (contains text like "X items left")

### 7. Filter Buttons
- **Filter Container**: `.filters`
- **All Filter**: `.filters a[href="#/"]`
- **Active Filter**: `.filters a[href="#/active"]`
- **Completed Filter**: `.filters a[href="#/completed"]`
- **Selected Filter**: `.filters a.selected`

### 8. Additional Key Selectors
- **Main Section**: `.main` (hidden when no todos)
- **Footer Section**: `.footer` (hidden when no todos)
- **Clear Completed**: `.clear-completed`
- **App Container**: `.todoapp`
- **Header**: `.header`

### 9. Data Test IDs
**Note**: The standard TodoMVC implementation does not include `data-testid` attributes. For test automation, you would typically add these yourself or use the CSS classes above. If implementing test IDs, recommended attributes would be:
- `data-testid="new-todo-input"`
- `data-testid="todo-item"`
- `data-testid="todo-toggle"`
- `data-testid="todo-label"`
- `data-testid="delete-button"`
- `data-testid="edit-input"`
- `data-testid="todo-count"`
- `data-testid="filter-all"`
- `data-testid="filter-active"`
- `data-testid="filter-completed"`
- `data-testid="clear-completed"`

---

# Comprehensive Test Plan for TodoMVC Application

## Test Scenarios

### Scenario 1: Initial Page Load and Basic UI Verification
**Objective**: Verify the application loads correctly with proper initial state

**Steps**:
1. Navigate to the TodoMVC demo URL
2. Wait for page to fully load
3. Verify the page title contains "TodoMVC"
4. Verify the main input field (`.new-todo`) is visible and focused
5. Verify the input placeholder text reads "What needs to be done?"
6. Verify the main section (`.main`) is hidden when no todos exist
7. Verify the footer section (`.footer`) is hidden when no todos exist
8. Verify the "todos" heading is displayed

**Expected Results**:
- Application loads without errors
- Input field is focused and ready for input
- UI sections are properly hidden/shown based on empty state

### Scenario 2: Creating New Todos
**Objective**: Test the ability to create new todo items

**Steps**:
1. Click on the new todo input field (`.new-todo`)
2. Type "Learn Playwright testing" and press Enter
3. Verify the todo appears in the list (`.todo-list li`)
4. Verify the input field is cleared after creation
5. Verify the main section (`.main`) becomes visible
6. Verify the footer section (`.footer`) becomes visible
7. Add a second todo: "Write comprehensive tests"
8. Verify both todos appear in the list
9. Verify the todo count shows "2 items left" (`.todo-count`)

**Expected Results**:
- New todos are successfully created and displayed
- Counter updates correctly
- UI sections become visible after first todo

### Scenario 3: Todo Input Validation
**Objective**: Test input validation and edge cases

**Steps**:
1. Try to create a todo with only spaces: "   " + Enter
2. Verify no todo is created
3. Try to create a todo with empty input: press Enter without typing
4. Verify no todo is created
5. Create a todo with special characters: "Test @#$%^&*()" + Enter
6. Verify the todo is created with special characters intact
7. Create a very long todo (200+ characters) + Enter
8. Verify the todo is created and displayed properly

**Expected Results**:
- Empty and whitespace-only inputs are rejected
- Special characters are handled correctly
- Long text is accommodated or properly truncated

### Scenario 4: Marking Todos as Complete/Incomplete
**Objective**: Test the toggle functionality for individual todos

**Steps**:
1. Create two todos: "First task" and "Second task"
2. Click the checkbox (`.toggle`) next to "First task"
3. Verify the todo gets `completed` class
4. Verify the checkbox shows as checked
5. Verify the todo counter updates to "1 item left"
6. Click the checkbox again to uncheck
7. Verify the `completed` class is removed
8. Verify the counter updates to "2 items left"

**Expected Results**:
- Todos can be marked as complete/incomplete
- Visual styling changes appropriately
- Counter updates reflect current state

### Scenario 5: Toggle All Functionality
**Objective**: Test the "Mark all as complete" checkbox functionality

**Steps**:
1. Create three todos
2. Click the toggle-all checkbox (`#toggle-all` or `.toggle-all`)
3. Verify all todos are marked as completed
4. Verify the counter shows "0 items left"
5. Click toggle-all again to uncheck
6. Verify all todos are marked as incomplete
7. Manually check one todo, then check toggle-all
8. Verify all todos become completed

**Expected Results**:
- Toggle-all affects all todo items simultaneously
- Counter reflects the change accurately
- Individual and bulk operations work together correctly

### Scenario 6: Editing Todos
**Objective**: Test the editing functionality for existing todos

**Steps**:
1. Create a todo: "Original text"
2. Double-click on the todo label (`.view label`)
3. Verify the todo enters editing mode (`.editing` class applied)
4. Verify the edit input (`.edit`) becomes visible and focused
5. Clear the text and type "Edited text"
6. Press Enter to save
7. Verify the todo text is updated
8. Verify editing mode is exited
9. Double-click another todo to edit
10. Press Escape key
11. Verify changes are discarded and editing mode is exited

**Expected Results**:
- Double-click activates edit mode
- Enter saves changes
- Escape discards changes
- Text updates properly after editing

### Scenario 7: Editing Validation
**Objective**: Test edge cases in editing functionality

**Steps**:
1. Create a todo: "Test todo"
2. Double-click to edit
3. Clear all text (make it empty) and press Enter
4. Verify the todo is deleted completely
5. Create another todo: "Another test"
6. Double-click to edit
7. Change text to only spaces: "   " and press Enter
8. Verify the todo is deleted
9. Create a todo and edit with very long text (200+ chars)
10. Verify the change is saved properly

**Expected Results**:
- Empty edits result in todo deletion
- Whitespace-only edits result in todo deletion
- Long text is handled appropriately

### Scenario 8: Deleting Todos
**Objective**: Test the delete functionality

**Steps**:
1. Create two todos
2. Hover over the first todo
3. Verify the delete button (`.destroy`) becomes visible
4. Click the delete buton
5. Verify the todo is removed from the list
6. Verify the counter updates correctly
7. Delete the remaining todo
8. Verify the main and footer sections become hidden

**Expected Results**:
- Delete button appears on hover
- Todos are successfully deleted
- UI updates appropriately when all todos are deleted

### Scenario 9: Filtering Functionality
**Objective**: Test the All/Active/Completed filter functionality

**Steps**:
1. Create three todos: "Task 1", "Task 2", "Task 3"
2. Mark "Task 2" as completed
3. Click "Active" filter (`.filters a[href="#/active"]`)
4. Verify only "Task 1" and "Task 3" are visible
5. Verify the URL contains "#/active"
6. Click "Completed" filter (`.filters a[href="#/completed"]`)
7. Verify only "Task 2" is visible
8. Verify the URL contains "#/completed"
9. Click "All" filter (`.filters a[href="#/"]`)
10. Verify all three todos are visible
11. Verify the correct filter has the `selected` class

**Expected Results**:
- Filtering works correctly for all states
- URL routing updates appropriately
- Visual indicators show active filter

### Scenario 10: Clear Completed Functionality
**Objective**: Test the "Clear completed" button

**Steps**:
1. Create three todos
2. Mark two todos as completed
3. Verify the "Clear completed" button (`.clear-completed`) is visible
4. Click the "Clear completed" button
5. Verify only the incomplete todo remains
6. Verify the button is hidden when no completed todos exist
7. Mark the remaining todo as complete
8. Verify the button reappears
9. Click to clear the last completed todo
10. Verify the main and footer sections are hidden

**Expected Results**:
- Clear completed removes only completed todos
- Button visibility updates based on completed todos presence
- UI state updates correctly after clearing

### Scenario 11: Persistence Testing
**Objective**: Test localStorage persistence functionality

**Steps**:
1. Create two todos: "Persistent task 1" and "Persistent task 2"
2. Mark one as completed
3. Set filter to "Active"
4. Refresh the page
5. Verify todos are still present
6. Verify completion states are preserved
7. Verify the active filter is still selected
8. Open browser developer tools and check localStorage
9. Verify todo data is stored with proper keys

**Expected Results**:
- Todo data persists across page refreshes
- Completion states are maintained
- Filter selection is preserved
- localStorage contains properly formatted data

### Scenario 12: Cross-Browser Compatibility
**Objective**: Verify functionality across different browsers

**Steps**:
1. Repeat core functionality tests in Chrome
2. Repeat core functionality tests in Firefox
3. Repeat core functionality tests in Safari (if available)
4. Repeat core functionality tests in Edge
5. Test on mobile browsers (iOS Safari, Chrome Mobile)
6. Verify keyboard navigation works in all browsers
7. Verify visual styling is consistent

**Expected Results**:
- All functionality works consistently across browsers
- Visual appearance is consistent
- No JavaScript errors in any browser

### Scenario 13: Keyboard Navigation and Accessibility
**Objective**: Test keyboard accessibility and navigation

**Steps**:
1. Navigate using only keyboard (Tab, Shift+Tab)
2. Verify all interactive elements are reachable
3. Test Enter key for creating todos
4. Test Escape key for canceling edits
5. Test Space bar for toggling checkboxes
6. Verify focus indicators are visible
7. Test with screen reader (if available)

**Expected Results**:
- Full keyboard navigation is possible
- Focus indicators are clear and visible
- Standard keyboard shortcuts work as expected

### Scenario 14: Performance and Edge Cases
**Objective**: Test application performance with large datasets

**Steps**:
1. Create 100 todos programmatically
2. Verify the application remains responsive
3. Test filtering with large number of todos
4. Test toggle-all with many todos
5. Test scrolling behavior with many todos
6. Clear all todos and verif performance
7. Test rapid creation/deletion of todos

**Expected Results**:
- Application handles large datasets gracefully
- No significant performance degradation
- UI remains responsive during bulk operations

### Scenario 15: Error Handling and Recovery
**Objective**: Test application behavior under error conditions

**Steps**:
1. Simulate network disconnection during usage
2. Try to create todos while offline
3. Reconnect and verify data integrity
4. Simulate localStorage quota exceeded
5. Test with JavaScript errors injected
6. Verify graceful degradation

**Expected Results**:
- Application handles errors gracefully
- No data loss during error conditions
- User receives appropriate feedback

## Test Execution Notes

**Browser Support**: Test on Chrome, Firefox, Safari, and Edge
**Device Testing**: Include mobile and tablet testing
**Automation**: These tests can be automated using Playwright, Cypress, or similar tools
**Performance**: Monitor for memory leaks during extended testing sessions
**Accessibility**: Use tools like axe-core for automated accessibility testing

## Success Criteria

A test run is considered successful when:
- All functional requirements work as specified
- No JavaScript errors occur during testing
- Data persistence works correctly
- Cross-browser compatibility is maintained
- Accessibility standards are met
- Performance remains acceptable under normal and stress conditionsroot

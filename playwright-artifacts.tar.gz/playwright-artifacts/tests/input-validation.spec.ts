import { test, expect } from '@playwright/test';

test.describe('Input Validation and Edge Cases', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
  });

  test('should not add empty todo', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Try to submit empty input
    await todoInput.click();
    await todoInput.press('Enter');
    
    // Verify no todo is added
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    await expect(page.locator('.todo-list')).not.toBeVisible();
    
    // Input should remain focused and empty
    await expect(todoInput).toBeFocused();
    await expect(todoInput).toHaveValue('');
  });

  test('should not add whitespace-only todo', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Try to submit whitespace-only input
    await todoInput.fill('   ');
    await todoInput.press('Enter');
    
    // Verify no todo is added
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    await expect(page.locator('.todo-list')).not.toBeVisible();
    
    // Input should retain the whitespace (application behavior)
    await expect(todoInput).toHaveValue('   ');
  });

  test('should trim whitespace from todo text', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add todo with leading and trailing whitespace
    await todoInput.fill('  Todo with spaces  ');
    await todoInput.press('Enter');
    
    // Verify whitespace is trimmed
    await expect(page.getByTestId('todo-title')).toHaveText('Todo with spaces');
  });

  test('should handle very long todo text', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Create a very long todo text (300+ characters)
    const longText = 'This is a very long todo item that contains more than 300 characters to test how the application handles extremely long text inputs and whether it can display them properly without breaking the layout or causing any issues with the user interface components and functionality. This text should wrap appropriately and maintain usability.';
    
    await todoInput.fill(longText);
    await todoInput.press('Enter');
    
    // Verify todo is added successfully
    await expect(page.getByTestId('todo-title')).toHaveText(longText);
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
    
    // Verify functionality still works with long text
    await page.locator('.toggle').click();
    await expect(page.getByTestId('todo-item')).toHaveClass(/completed/);
    
    // Verify editing works with long text
    await page.getByTestId('todo-title').dblclick();
    const editInput = page.locator('.edit');
    await expect(editInput).toHaveValue(longText);
  });

  test('should handle special characters in todo text', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    const specialCharTodos = [
      'Buy 2 @ $5.99 each',
      'Meeting at 3:30 PM',
      'Review PR #123',
      'Unicode: 🚀 ✨ 📝',
      'Symbols: !@#$%^&*()_+-={}[]|;:,.<>?'
    ];
    
    for (const todo of specialCharTodos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Verify all special character todos are displayed correctly
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(5);
    
    for (let i = 0; i < specialCharTodos.length; i++) {
      await expect(todoItems.nth(i).getByTestId('todo-title')).toHaveText(specialCharTodos[i]);
    }
    
    // Test editing with special characters
    await todoItems.nth(0).getByTestId('todo-title').dblclick();
    const editInput = todoItems.nth(0).locator('.edit');
    await expect(editInput).toHaveValue('Buy 2 @ $5.99 each');
    
    await editInput.fill('Updated: Buy 3 @ $4.99 each');
    await editInput.press('Enter');
    
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Updated: Buy 3 @ $4.99 each');
  });

  test('should handle HTML and script injection attempts', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    const maliciousInputs = [
      '<script>alert("xss")</script>',
      '<img src="x" onerror="alert(1)">',
      '<svg onload="alert(1)">',
      '&lt;script&gt;alert("encoded")&lt;/script&gt;'
    ];
    
    for (const input of maliciousInputs) {
      await todoInput.fill(input);
      await todoInput.press('Enter');
    }
    
    // Verify the content is treated as plain text, not executed as HTML/JS
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(4);
    
    // Verify no script execution occurred (no alerts)
    for (let i = 0; i < maliciousInputs.length; i++) {
      await expect(todoItems.nth(i).getByTestId('todo-title')).toHaveText(maliciousInputs[i]);
    }
  });

  test('should handle rapid consecutive additions', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Rapidly add multiple todos
    const rapidTodos = Array.from({ length: 10 }, (_, i) => `Rapid todo ${i + 1}`);
    
    for (const todo of rapidTodos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
      // Small delay to simulate rapid but not instantaneous input
      await page.waitForTimeout(50);
    }
    
    // Verify all todos were added correctly
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(10);
    
    for (let i = 0; i < rapidTodos.length; i++) {
      await expect(todoItems.nth(i).getByTestId('todo-title')).toHaveText(rapidTodos[i]);
    }
    
    // Verify counter is correct
    await expect(page.locator('.todo-count')).toHaveText('10 items left');
  });

  test('should handle empty edit submission', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Todo to edit');
    await todoInput.press('Enter');
    
    // Start editing
    await page.getByTestId('todo-title').dblclick();
    
    // Clear the edit input and submit
    const editInput = page.locator('.edit');
    await editInput.fill('');
    await editInput.press('Enter');
    
    // Verify the todo is deleted when edited to empty string
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    await expect(page.locator('.todo-list')).not.toBeVisible();
  });

  test('should handle edit with only whitespace', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Todo to edit');
    await todoInput.press('Enter');
    
    // Start editing
    await page.getByTestId('todo-title').dblclick();
    
    // Edit to whitespace only
    const editInput = page.locator('.edit');
    await editInput.fill('   ');
    await editInput.press('Enter');
    
    // Verify the todo is deleted when edited to whitespace only
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    await expect(page.locator('.todo-list')).not.toBeVisible();
  });

  test('should handle edit input blur without changes', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Original text');
    await todoInput.press('Enter');
    
    // Start editing
    await page.getByTestId('todo-title').dblclick();
    
    // Click outside to blur without making changes
    await page.click('body');
    
    // Verify original text is preserved and edit mode is exited
    await expect(page.getByTestId('todo-title')).toHaveText('Original text');
    await expect(page.locator('.edit')).not.toBeVisible();
  });
});
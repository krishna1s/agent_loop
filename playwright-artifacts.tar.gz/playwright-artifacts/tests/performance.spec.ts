import { test, expect } from '@playwright/test';

test.describe('Performance and Stress Testing', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
  });

  test('should handle large number of todos efficiently', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    const startTime = Date.now();
    
    // Add 100 todos
    for (let i = 1; i <= 100; i++) {
      await todoInput.fill(`Todo item ${i}`);
      await todoInput.press('Enter');
    }
    
    const addTime = Date.now() - startTime;
    
    // Verify all todos were added
    await expect(page.getByTestId('todo-item')).toHaveCount(100);
    await expect(page.locator('.todo-count')).toHaveText('100 items left');
    
    // Test filtering performance with many todos
    const filterStartTime = Date.now();
    
    // Mark some todos as completed
    for (let i = 0; i < 20; i++) {
      await page.getByTestId('todo-item').nth(i * 5).locator('.toggle').click();
    }
    
    // Test filter switching
    await page.getByRole('link', { name: 'Completed' }).click();
    await expect(page.getByTestId('todo-item')).toHaveCount(20);
    
    await page.getByRole('link', { name: 'Active' }).click();
    await expect(page.getByTestId('todo-item')).toHaveCount(80);
    
    await page.getByRole('link', { name: 'All' }).click();
    await expect(page.getByTestId('todo-item')).toHaveCount(100);
    
    const filterTime = Date.now() - filterStartTime;
    
    // Performance should be reasonable (adjust thresholds as needed)
    expect(addTime).toBeLessThan(30000); // 30 seconds for adding 100 todos
    expect(filterTime).toBeLessThan(5000); // 5 seconds for filtering operations
    
    console.log(`Adding 100 todos took: ${addTime}ms`);
    console.log(`Filtering operations took: ${filterTime}ms`);
  });

  test('should handle bulk operations efficiently', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add 50 todos
    for (let i = 1; i <= 50; i++) {
      await todoInput.fill(`Bulk test todo ${i}`);
      await todoInput.press('Enter');
    }
    
    const startTime = Date.now();
    
    // Test toggle-all performance
    await page.locator('#toggle-all').click();
    
    const toggleAllTime = Date.now() - startTime;
    
    // Verify all are completed
    await expect(page.locator('.todo-count')).toHaveText('0 items left');
    
    // Test clear completed performance
    const clearStartTime = Date.now();
    
    await page.locator('.clear-completed').click();
    
    const clearTime = Date.now() - clearStartTime;
    
    // Verify all todos are cleared
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    
    // Performance should be reasonable
    expect(toggleAllTime).toBeLessThan(2000); // 2 seconds for toggle-all
    expect(clearTime).toBeLessThan(2000); // 2 seconds for clear completed
    
    console.log(`Toggle-all for 50 todos took: ${toggleAllTime}ms`);
    console.log(`Clear completed for 50 todos took: ${clearTime}ms`);
  });

  test('should maintain performance with complex todo content', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Create todos with complex content
    const complexTodos = [
      'Todo with emoji 🚀 and symbols !@#$%^&*()',
      'Very long todo: ' + 'x'.repeat(500),
      'Todo with HTML-like content: <div>test</div>',
      'Todo with special chars: àáâãäåæçèéêë',
      'Todo with numbers and dates: 123-456-7890 2023-12-31'
    ];
    
    const startTime = Date.now();
    
    // Add complex todos multiple times
    for (let i = 0; i < 20; i++) {
      for (const todo of complexTodos) {
        await todoInput.fill(`${todo} #${i}`);
        await todoInput.press('Enter');
      }
    }
    
    const addTime = Date.now() - startTime;
    
    // Verify all todos were added
    await expect(page.getByTestId('todo-item')).toHaveCount(100);
    
    // Test editing performance with complex content
    const editStartTime = Date.now();
    
    await page.getByTestId('todo-item').nth(0).getByTestId('todo-title').dblclick();
    const editInput = page.locator('.edit');
    await editInput.fill('Updated complex todo with new content 📝');
    await editInput.press('Enter');
    
    const editTime = Date.now() - editStartTime;
    
    // Performance assertions
    expect(addTime).toBeLessThan(20000); // 20 seconds for adding 100 complex todos
    expect(editTime).toBeLessThan(1000); // 1 second for editing
    
    console.log(`Adding 100 complex todos took: ${addTime}ms`);
    console.log(`Editing complex todo took: ${editTime}ms`);
  });

  test('should handle rapid consecutive operations', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add base todos
    for (let i = 1; i <= 10; i++) {
      await todoInput.fill(`Rapid ops todo ${i}`);
      await todoInput.press('Enter');
    }
    
    const startTime = Date.now();
    
    // Perform rapid consecutive operations
    for (let i = 0; i < 5; i++) {
      // Toggle completion
      await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
      
      // Edit todo
      await page.getByTestId('todo-item').nth(1).getByTestId('todo-title').dblclick();
      const editInput = page.locator('.edit');
      await editInput.fill(`Rapidly edited ${i}`);
      await editInput.press('Enter');
      
      // Add new todo
      await todoInput.fill(`Rapid add ${i}`);
      await todoInput.press('Enter');
      
      // Delete todo
      await page.getByTestId('todo-item').nth(2).hover();
      await page.getByTestId('todo-item').nth(2).getByTestId('todo-item-destroy').click();
    }
    
    const rapidOpsTime = Date.now() - startTime;
    
    // Verify final state is consistent
    const todoCount = await page.getByTestId('todo-item').count();
    expect(todoCount).toBeGreaterThan(0);
    
    // Performance should be reasonable
    expect(rapidOpsTime).toBeLessThan(10000); // 10 seconds for rapid operations
    
    console.log(`Rapid consecutive operations took: ${rapidOpsTime}ms`);
  });

  test('should handle memory usage with many DOM manipulations', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Simulate memory-intensive operations
    for (let cycle = 0; cycle < 5; cycle++) {
      // Add many todos
      for (let i = 1; i <= 20; i++) {
        await todoInput.fill(`Memory test ${cycle}-${i}`);
        await todoInput.press('Enter');
      }
      
      // Mark all as completed
      await page.locator('#toggle-all').click();
      
      // Clear all completed
      await page.locator('.clear-completed').click();
      
      // Verify clean state
      await expect(page.getByTestId('todo-item')).toHaveCount(0);
    }
    
    // Add final todos to verify app still works
    await todoInput.fill('Final memory test todo');
    await todoInput.press('Enter');
    
    await expect(page.getByTestId('todo-item')).toHaveText('Final memory test todo');
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
  });

  test('should maintain responsiveness during heavy filtering', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add mixed todos (active and completed)
    for (let i = 1; i <= 50; i++) {
      await todoInput.fill(`Filter test todo ${i}`);
      await todoInput.press('Enter');
      
      // Complete every other todo
      if (i % 2 === 0) {
        await page.getByTestId('todo-item').nth(i - 1).locator('.toggle').click();
      }
    }
    
    // Test rapid filter switching
    const filterStartTime = Date.now();
    
    for (let i = 0; i < 10; i++) {
      await page.getByRole('link', { name: 'Active' }).click();
      await expect(page.getByTestId('todo-item')).toHaveCount(25);
      
      await page.getByRole('link', { name: 'Completed' }).click();
      await expect(page.getByTestId('todo-item')).toHaveCount(25);
      
      await page.getByRole('link', { name: 'All' }).click();
      await expect(page.getByTestId('todo-item')).toHaveCount(50);
    }
    
    const filterTime = Date.now() - filterStartTime;
    
    // Should maintain responsiveness
    expect(filterTime).toBeLessThan(15000); // 15 seconds for 30 filter operations
    
    console.log(`Heavy filtering operations took: ${filterTime}ms`);
  });
});
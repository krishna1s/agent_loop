import { test, expect } from '@playwright/test';

test.describe('User Experience and Accessibility', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
  });

  test('should support keyboard navigation', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add some todos
    await todoInput.fill('First todo');
    await todoInput.press('Enter');
    await todoInput.fill('Second todo');
    await todoInput.press('Enter');
    
    // Test Tab navigation through interactive elements
    // Start from the input which should be focused
    await todoInput.focus();
    
    // Tab to first checkbox
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab'); // May need extra tab depending on implementation
    
    // Use Space to toggle completion (regardless of exact focus)
    await page.keyboard.press('Space');
    
    // Check if any todo was toggled
    const completedTodos = await page.$$('.todo-list li.completed');
    expect(completedTodos.length).toBeGreaterThan(0);
    
    // Test filter navigation
    await page.getByRole('link', { name: 'Completed' }).focus();
    await page.keyboard.press('Enter');
    expect(page.url()).toContain('#/completed');
  });

  test('should have proper focus indicators', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Focus test todo');
    await todoInput.press('Enter');
    
    // Focus on a toggle directly
    await page.locator('.toggle').first().focus();
    
    // Verify element is focused
    await expect(page.locator('.toggle').first()).toBeFocused();
    
    // Check for focus styles (basic check)
    const hasFocusStyles = await page.locator('.toggle').first().evaluate(el => {
      const styles = window.getComputedStyle(el);
      return styles.outline !== 'none' || el === document.activeElement;
    });
    
    expect(hasFocusStyles).toBeTruthy();
  });

  test('should handle browser refresh with todos', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add some todos and complete one
    await todoInput.fill('Persistent todo 1');
    await todoInput.press('Enter');
    await todoInput.fill('Persistent todo 2');
    await todoInput.press('Enter');
    
    await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
    
    // Refresh the page
    await page.reload();
    
    // Check if todos persist (they do in this implementation)
    await expect(page.getByTestId('todo-item')).toHaveCount(2);
    await expect(page.getByTestId('todo-item').nth(0)).toHaveClass(/completed/);
  });

  test('should handle back/forward navigation with filters', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add test data
    await todoInput.fill('Navigation test todo');
    await todoInput.press('Enter');
    await page.locator('.toggle').click();
    
    // Navigate through filters
    await page.getByRole('link', { name: 'Active' }).click();
    expect(page.url()).toContain('#/active');
    
    await page.getByRole('link', { name: 'Completed' }).click();
    expect(page.url()).toContain('#/completed');
    
    // Use browser back button
    await page.goBack();
    expect(page.url()).toContain('#/active');
    await expect(page.getByRole('link', { name: 'Active' })).toHaveClass(/selected/);
    
    // Use browser forward button
    await page.goForward();
    expect(page.url()).toContain('#/completed');
    await expect(page.getByRole('link', { name: 'Completed' })).toHaveClass(/selected/);
  });

  test('should be responsive to different viewport sizes', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Responsive test todo');
    await todoInput.press('Enter');
    
    // Test mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Verify main elements are still visible and functional
    await expect(todoInput).toBeVisible();
    await expect(page.getByTestId('todo-item')).toBeVisible();
    
    // Test that adding todos still works
    await todoInput.fill('Mobile todo');
    await todoInput.press('Enter');
    await expect(page.getByTestId('todo-item')).toHaveCount(2);
    
    // Test tablet viewport
    await page.setViewportSize({ width: 768, height: 1024 });
    
    // Verify functionality still works
    await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
    await expect(page.getByTestId('todo-item').nth(0)).toHaveClass(/completed/);
    
    // Test desktop viewport
    await page.setViewportSize({ width: 1200, height: 800 });
    
    // Verify all functionality still works
    await expect(page.getByTestId('todo-item')).toHaveCount(2);
    await expect(page.getByTestId('todo-count')).toHaveText('1 item left');
  });

  test('should handle multiple browser tabs', async ({ context }) => {
    // Create two pages (tabs)
    const page1 = await context.newPage();
    const page2 = await context.newPage();
    
    // Navigate both to the app
    await page1.goto('https://demo.playwright.dev/todomvc/#/');
    await page2.goto('https://demo.playwright.dev/todomvc/#/');
    
    // Add todo in first tab
    await page1.getByPlaceholder('What needs to be done?').fill('Tab 1 todo');
    await page1.getByPlaceholder('What needs to be done?').press('Enter');
    
    // Add todo in second tab
    await page2.getByPlaceholder('What needs to be done?').fill('Tab 2 todo');
    await page2.getByPlaceholder('What needs to be done?').press('Enter');
    
    // Verify each tab maintains its own state (unless synced via storage)
    await expect(page1.getByTestId('todo-title')).toHaveText('Tab 1 todo');
    await expect(page2.getByTestId('todo-title')).toHaveText('Tab 2 todo');
    
    // Clean up
    await page1.close();
    await page2.close();
  });

  test('should display proper todo count with various states', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // No todos - counter should not be visible
    await expect(page.locator('.todo-count')).not.toBeVisible();
    
    // Add one todo
    await todoInput.fill('Count test todo');
    await todoInput.press('Enter');
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
    
    // Add another todo
    await todoInput.fill('Second count todo');
    await todoInput.press('Enter');
    await expect(page.locator('.todo-count')).toHaveText('2 items left');
    
    // Complete one todo
    await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
    
    // Complete all todos
    await page.getByTestId('todo-item').nth(1).locator('.toggle').click();
    await expect(page.locator('.todo-count')).toHaveText('0 items left');
    
    // Make one active again
    await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
  });

  test('should handle rapid user interactions gracefully', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Rapid interaction test');
    await todoInput.press('Enter');
    
    // Rapidly toggle completion state
    const toggle = page.locator('.toggle');
    for (let i = 0; i < 10; i++) {
      await toggle.click();
      await page.waitForTimeout(10); // Small delay to simulate rapid clicking
    }
    
    // Verify final state is consistent
    const isCompleted = await page.getByTestId('todo-item').getAttribute('class');
    const expectedCount = isCompleted?.includes('completed') ? '0 items left' : '1 item left';
    await expect(page.locator('.todo-count')).toHaveText(expectedCount);
    
    // Test rapid editing
    await page.getByTestId('todo-title').dblclick();
    const editInput = page.locator('.edit');
    
    // Rapidly change text multiple times
    for (let i = 0; i < 5; i++) {
      await editInput.fill(`Rapid edit ${i}`);
      await page.waitForTimeout(50);
    }
    
    await editInput.press('Enter');
    await expect(page.getByTestId('todo-title')).toHaveText('Rapid edit 4');
  });
});
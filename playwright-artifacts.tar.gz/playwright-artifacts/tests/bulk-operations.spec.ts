import { test, expect } from '@playwright/test';

test.describe('Bulk Operations', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
  });

  test('should toggle all todos to complete', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add multiple todos
    const todos = ['Todo 1', 'Todo 2', 'Todo 3'];
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Click toggle-all button
    await page.locator('#toggle-all').click();
    
    // Verify all todos are marked as completed
    const todoItems = page.getByTestId('todo-item');
    for (let i = 0; i < todos.length; i++) {
      await expect(todoItems.nth(i)).toHaveClass(/completed/);
    }
    
    // Verify counter shows 0 items left
    await expect(page.locator('.todo-count')).toHaveText('0 items left');
    
    // Verify toggle-all is in checked state
    await expect(page.locator('#toggle-all')).toBeChecked();
  });

  test('should toggle all todos to incomplete', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add multiple todos and mark them as completed
    const todos = ['Todo 1', 'Todo 2', 'Todo 3'];
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Mark all as completed first
    await page.locator('#toggle-all').click();
    
    // Click toggle-all again to mark all as incomplete
    await page.locator('#toggle-all').click();
    
    // Verify all todos are active
    const todoItems = page.getByTestId('todo-item');
    for (let i = 0; i < todos.length; i++) {
      await expect(todoItems.nth(i)).not.toHaveClass(/completed/);
    }
    
    // Verify counter shows correct count
    await expect(page.locator('.todo-count')).toHaveText('3 items left');
    
    // Verify toggle-all is in unchecked state
    await expect(page.locator('#toggle-all')).not.toBeChecked();
  });

  test('should clear completed todos', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add four todos
    const todos = ['Todo 1', 'Todo 2', 'Todo 3', 'Todo 4'];
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Mark Todo 2 and Todo 4 as completed
    await page.getByTestId('todo-item').nth(1).locator('.toggle').click();
    await page.getByTestId('todo-item').nth(3).locator('.toggle').click();
    
    // Click Clear completed button
    await page.locator('.clear-completed').click();
    
    // Verify only active todos remain
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(2);
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Todo 1');
    await expect(todoItems.nth(1).getByTestId('todo-title')).toHaveText('Todo 3');
    
    // Verify counter shows correct count
    await expect(page.locator('.todo-count')).toHaveText('2 items left');
    
    // Verify Clear completed button is not visible when no completed todos
    await expect(page.locator('.clear-completed')).not.toBeVisible();
  });

  test('should show/hide Clear completed button appropriately', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Test todo');
    await todoInput.press('Enter');
    
    // Initially, Clear completed should not be visible
    await expect(page.locator('.clear-completed')).not.toBeVisible();
    
    // Mark todo as completed
    await page.locator('.toggle').click();
    
    // Clear completed button should now be visible
    await expect(page.locator('.clear-completed')).toBeVisible();
    
    // Clear completed todos
    await page.locator('.clear-completed').click();
    
    // Button should be hidden again
    await expect(page.locator('.clear-completed')).not.toBeVisible();
  });

  test('should handle toggle-all with mixed completion states', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add three todos
    const todos = ['Todo 1', 'Todo 2', 'Todo 3'];
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Mark only the second todo as completed
    await page.getByTestId('todo-item').nth(1).locator('.toggle').click();
    
    // Toggle-all should complete all remaining active todos
    await page.locator('#toggle-all').click();
    
    // Verify all todos are now completed
    const todoItems = page.getByTestId('todo-item');
    for (let i = 0; i < todos.length; i++) {
      await expect(todoItems.nth(i)).toHaveClass(/completed/);
    }
    
    // Verify counter shows 0 items left
    await expect(page.locator('.todo-count')).toHaveText('0 items left');
  });

  test('should handle Clear completed with filter active', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add and complete some todos
    const todos = ['Active 1', 'Completed 1', 'Active 2', 'Completed 2'];
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Mark todos with "Completed" in name as completed
    await page.getByTestId('todo-item').nth(1).locator('.toggle').click();
    await page.getByTestId('todo-item').nth(3).locator('.toggle').click();
    
    // Switch to Completed filter
    await page.getByRole('link', { name: 'Completed' }).click();
    
    // Clear completed todos
    await page.locator('.clear-completed').click();
    
    // Should show empty state in Completed filter
    await expect(page.getByTestId('todo-item')).toHaveCount(0);
    
    // Switch back to All to verify only active todos remain
    await page.getByRole('link', { name: 'All' }).click();
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(2);
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Active 1');
    await expect(todoItems.nth(1).getByTestId('todo-title')).toHaveText('Active 2');
  });
});
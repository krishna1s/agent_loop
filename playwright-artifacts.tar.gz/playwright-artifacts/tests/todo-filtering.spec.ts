import { test, expect } from '@playwright/test';

test.describe('Todo Filtering', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
    
    // Add test data: some active and some completed todos
    const todoInput = page.getByPlaceholder('What needs to be done?');
    const todos = ['Active todo 1', 'Active todo 2', 'Todo to complete'];
    
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Mark the third todo as completed
    await page.getByTestId('todo-item').nth(2).locator('.toggle').click();
  });

  test('should show all todos in All filter', async ({ page }) => {
    // Click All filter
    await page.getByRole('link', { name: 'All' }).click();
    
    // Verify URL fragment
    expect(page.url()).toContain('#/');
    
    // Verify all todos are visible
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(3);
    
    // Verify both active and completed todos are shown
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Active todo 1');
    await expect(todoItems.nth(1).getByTestId('todo-title')).toHaveText('Active todo 2');
    await expect(todoItems.nth(2).getByTestId('todo-title')).toHaveText('Todo to complete');
    await expect(todoItems.nth(2)).toHaveClass(/completed/);
    
    // Verify All filter is highlighted
    await expect(page.getByRole('link', { name: 'All' })).toHaveClass(/selected/);
  });

  test('should show only active todos in Active filter', async ({ page }) => {
    // Click Active filter
    await page.getByRole('link', { name: 'Active' }).click();
    
    // Verify URL fragment
    expect(page.url()).toContain('#/active');
    
    // Verify only active todos are visible
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(2);
    
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Active todo 1');
    await expect(todoItems.nth(1).getByTestId('todo-title')).toHaveText('Active todo 2');
    
    // Verify completed todo is not visible
    await expect(page.getByText('Todo to complete')).not.toBeVisible();
    
    // Verify Active filter is highlighted
    await expect(page.getByRole('link', { name: 'Active' })).toHaveClass(/selected/);
  });

  test('should show only completed todos in Completed filter', async ({ page }) => {
    // Click Completed filter
    await page.getByRole('link', { name: 'Completed' }).click();
    
    // Verify URL fragment
    expect(page.url()).toContain('#/completed');
    
    // Verify only completed todos are visible
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(1);
    
    await expect(todoItems.nth(0).getByTestId('todo-title')).toHaveText('Todo to complete');
    await expect(todoItems.nth(0)).toHaveClass(/completed/);
    
    // Verify active todos are not visible
    await expect(page.getByText('Active todo 1')).not.toBeVisible();
    await expect(page.getByText('Active todo 2')).not.toBeVisible();
    
    // Verify Completed filter is highlighted
    await expect(page.getByRole('link', { name: 'Completed' })).toHaveClass(/selected/);
  });

  test('should maintain filter state when adding new todos', async ({ page }) => {
    // Switch to Active filter
    await page.getByRole('link', { name: 'Active' }).click();
    
    // Add a new todo
    const todoInput = page.getByPlaceholder('What needs to be done?');
    await todoInput.fill('New active todo');
    await todoInput.press('Enter');
    
    // Verify new todo appears in active filter
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(3);
    await expect(todoItems.nth(2).getByTestId('todo-title')).toHaveText('New active todo');
    
    // Verify we're still in Active filter
    expect(page.url()).toContain('#/active');
    await expect(page.getByRole('link', { name: 'Active' })).toHaveClass(/selected/);
  });

  test('should update filters when todo status changes', async ({ page }) => {
    // Start in Active filter
    await page.getByRole('link', { name: 'Active' }).click();
    
    // Mark an active todo as complete
    await page.getByTestId('todo-item').nth(0).locator('.toggle').click();
    
    // Verify the todo disappears from Active view
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(1);
    await expect(page.getByText('Active todo 1')).not.toBeVisible();
    
    // Switch to Completed filter
    await page.getByRole('link', { name: 'Completed' }).click();
    
    // Verify the todo now appears in Completed view
    await expect(page.getByTestId('todo-item')).toHaveCount(2);
    await expect(page.getByText('Active todo 1')).toBeVisible();
  });

  test('should handle direct URL navigation to filters', async ({ page }) => {
    // Navigate directly to active filter URL
    await page.goto('https://demo.playwright.dev/todomvc/#/active');
    
    // Add test data
    const todoInput = page.getByPlaceholder('What needs to be done?');
    await todoInput.fill('Direct nav todo');
    await todoInput.press('Enter');
    
    // Verify Active filter is selected
    await expect(page.getByRole('link', { name: 'Active' })).toHaveClass(/selected/);
    
    // Navigate directly to completed filter URL
    await page.goto('https://demo.playwright.dev/todomvc/#/completed');
    
    // Verify Completed filter is selected
    await expect(page.getByRole('link', { name: 'Completed' })).toHaveClass(/selected/);
  });
});
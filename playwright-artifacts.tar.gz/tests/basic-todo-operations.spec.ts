import { test, expect } from '@playwright/test';

test.describe('Basic Todo Operations', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://demo.playwright.dev/todomvc/#/');
  });

  test('should add a new todo item', async ({ page }) => {
    // Locate the input field
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a new todo
    await todoInput.fill('Buy groceries');
    await todoInput.press('Enter');
    
    // Verify the todo appears in the list
    await expect(page.getByTestId('todo-title')).toHaveText('Buy groceries');
    
    // Verify the input field is cleared
    await expect(todoInput).toHaveValue('');
    
    // Verify the counter shows 1 item left
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
  });

  test('should add multiple todo items', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add three todos
    const todos = [
      'Complete project documentation',
      'Review code changes',
      'Schedule team meeting'
    ];
    
    for (const todo of todos) {
      await todoInput.fill(todo);
      await todoInput.press('Enter');
    }
    
    // Verify all todos appear in order
    const todoItems = page.getByTestId('todo-item');
    await expect(todoItems).toHaveCount(3);
    
    for (let i = 0; i < todos.length; i++) {
      await expect(todoItems.nth(i).getByTestId('todo-title')).toHaveText(todos[i]);
    }
    
    // Verify counter shows correct count
    await expect(page.locator('.todo-count')).toHaveText('3 items left');
  });

  test('should mark todo as complete', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Test todo completion');
    await todoInput.press('Enter');
    
    // Mark as complete
    await page.locator('.toggle').click();
    
    // Verify todo is marked as completed
    await expect(page.getByTestId('todo-item')).toHaveClass(/completed/);
    await expect(page.locator('.todo-count')).toHaveText('0 items left');
  });

  test('should mark todo as incomplete', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Test todo toggle');
    await todoInput.press('Enter');
    
    // Mark as complete
    await page.locator('.toggle').click();
    
    // Mark as incomplete again
    await page.locator('.toggle').click();
    
    // Verify todo is back to active state
    await expect(page.getByTestId('todo-item')).not.toHaveClass(/completed/);
    await expect(page.locator('.todo-count')).toHaveText('1 item left');
  });

  test('should edit todo item via double-click', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Original todo text');
    await todoInput.press('Enter');
    
    // Double-click to edit
    await page.getByTestId('todo-title').dblclick();
    
    // Verify edit mode is active
    const editInput = page.locator('.edit');
    await expect(editInput).toBeVisible();
    await expect(editInput).toHaveValue('Original todo text');
    
    // Edit the text
    await editInput.fill('Updated todo text');
    await editInput.press('Enter');
    
    // Verify the updated text is displayed
    await expect(page.getByTestId('todo-title')).toHaveText('Updated todo text');
    await expect(editInput).not.toBeVisible();
  });

  test('should cancel todo edit with Escape key', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Original text');
    await todoInput.press('Enter');
    
    // Double-click to edit
    await page.getByTestId('todo-title').dblclick();
    
    // Modify text but cancel with Escape
    const editInput = page.locator('.edit');
    await editInput.fill('Modified text');
    await editInput.press('Escape');
    
    // Verify original text is preserved
    await expect(page.getByTestId('todo-title')).toHaveText('Original text');
    await expect(editInput).not.toBeVisible();
  });

  test('should delete todo item', async ({ page }) => {
    const todoInput = page.getByPlaceholder('What needs to be done?');
    
    // Add a todo
    await todoInput.fill('Todo to be deleted');
    await todoInput.press('Enter');
    
    // Hover over todo to reveal delete button
    const todoItem = page.getByTestId('todo-item');
    await todoItem.hover();
    
    // Click delete button
    await page.locator('.destroy').click();
    
    // Verify todo is removed
    await expect(todoItem).not.toBeVisible();
    await expect(page.locator('.todo-count')).not.toBeVisible();
  });

  test('should handle empty state correctly', async ({ page }) => {
    // Verify empty state
    await expect(page.locator('.todo-list')).not.toBeVisible();
    await expect(page.locator('.todo-count')).not.toBeVisible();
    await expect(page.locator('.filters')).not.toBeVisible();
    
    // Input should still be available
    await expect(page.getByPlaceholder('What needs to be done?')).toBeVisible();
  });
});